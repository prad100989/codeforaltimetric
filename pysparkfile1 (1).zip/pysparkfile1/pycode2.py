import pandas as pd


data = pd.read_csv("/6617896ff007507fbd3ff29a/Project-Default/Coding Challenge/proj1/pysparkfile1/data.csv")

data['revenue'] = data['units_sold'] * data['unit_price']


print(data.head())
