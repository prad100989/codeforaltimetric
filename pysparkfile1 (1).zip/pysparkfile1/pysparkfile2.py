from pyspark.sql import SparkSession


spark = SparkSession.builder \
    .appName("Sample Spark SQL") \
    .getOrCreate()

df = spark.read.csv("data.csv", header=True, inferSchema=True)


df.createOrReplaceTempView("sales_transactions")


result = spark.sql("""
    SELECT
        product_id,
        SUM(units_sold) AS total_unit_sold
    FROM
        sales_transactions
    GROUP BY
        product_id
""")


result.show()

result.toPandas()


spark.stop()
