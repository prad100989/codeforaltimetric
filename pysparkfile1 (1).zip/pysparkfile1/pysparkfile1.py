from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when,lit


spark = SparkSession.builder.appName("DataPipeline").getOrCreate()


data = spark.read.csv("/home/ec2-user/environment/6617896ff007507fbd3ff29a/Project-Default/Coding Challenge/proj1/pysparkfile1/file.csv", header=True)

cleaned_data = data.select(
    col("col1"),
    col("col2"),
    when(col("col3").isNull(), 0).otherwise(col("col3")).alias("col3")
)


df2=cleaned_data.withColumn('new_col',lit('somevalue'))

df2.show()


df2.write.mode("overwrite").parquet("/6617896ff007507fbd3ff29a/Project-Default/Coding Challenge/proj1/pysparkfile1/")


spark.stop()
